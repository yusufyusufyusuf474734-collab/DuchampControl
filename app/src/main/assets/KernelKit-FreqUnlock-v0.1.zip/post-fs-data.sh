#!/system/bin/sh
# KernelKit FreqUnlock - post-fs-data.sh
# Bu aşama thermal modül yüklenmeden önce çalışır
LOG="/data/local/tmp/kernelkit_pfd.log"
echo "[$(date '+%H:%M:%S')] post-fs-data başladı" >> "$LOG"

# policy üzerinden yaz
echo 2200000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
echo 3200000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
echo 3350000 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null

# cpu node üzerinden de yaz
for cpu in 0 1 2 3; do
    echo 2200000 > /sys/devices/system/cpu/cpu${cpu}/cpufreq/scaling_max_freq 2>/dev/null
done
for cpu in 4 5 6; do
    echo 3200000 > /sys/devices/system/cpu/cpu${cpu}/cpufreq/scaling_max_freq 2>/dev/null
done
echo 3350000 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq 2>/dev/null

echo "[$(date '+%H:%M:%S')] cpu7 max: $(cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq 2>/dev/null)" >> "$LOG"
