#!/system/bin/sh
# KernelKit FreqUnlock - Kurulum scripti

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  KernelKit FreqUnlock v0.1"
ui_print "  Gelistirici: Sinan Aslan"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
ui_print "• MTK thermal kısıtlaması kaldırılacak"
ui_print "• CPU: Little 2200 / Big 3200 / Prime 3350 MHz"
ui_print "• GPU: 125 MHz - 1400 MHz"
ui_print "• KernelKit uygulaması ile senkronize çalışır"
ui_print ""

# service.sh çalıştırılabilir yap
set_perm "$MODPATH/service.sh" root root 0755
