#!/system/bin/sh
# KernelKit FreqUnlock - service.sh
# Gelistirici: Sinan Aslan | Versiyon: v0.1
#
# Senaryolar (otomatik mod):
#   POWERSAVE  — Pil < %20 veya şarj yok + ekran kapalı
#   BALANCED   — Normal kullanım (varsayılan)
#   PERFORMANCE — Şarjda veya pil > %80
#   GAMING     — Oyun uygulaması ön planda (GameDetectorService ile senkron)
#
# Uygulama modu (KernelKit ayarları):
#   SharedPreferences'ta "freq_mode" = "auto" | "manual"
#   Manual modda uygulama değerleri doğrudan uygulanır.

LOG="/data/local/tmp/kernelkit_freq.log"
PREFS="/data/data/com.cpucontrol/shared_prefs/cpu_prefs.xml"
GAME_FLAG="/data/local/tmp/kernelkit_gaming"
GPU_PATH="/sys/devices/platform/soc/13000000.mali/devfreq/13000000.mali"

# ── Profil frekansları ───────────────────────────────────────────────────────
# Little (cpu0-3) | Big (cpu4-6) | Prime (cpu7) | GPU min | GPU max
# Format: LITTLE_MIN LITTLE_MAX BIG_MIN BIG_MAX PRIME_MIN PRIME_MAX GPU_MIN GPU_MAX

POWERSAVE_PROFILE="480000 1800000 480000 2200000 480000 2200000 265000000 800000000"
BALANCED_PROFILE="480000 2200000 480000 3000000 480000 2800000 265000000 1045000000"
PERFORMANCE_PROFILE="480000 2200000 480000 3200000 480000 3350000 265000000 1400000000"
GAMING_PROFILE="480000 2200000 480000 3200000 480000 3350000 800000000 1400000000"

log() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG"; }

# ── SharedPreferences okuyucu ────────────────────────────────────────────────
read_pref_int() {
    local key="$1" default="$2"
    [ -f "$PREFS" ] || { echo "$default"; return; }
    val=$(grep "name=\"$key\"" "$PREFS" | grep -o 'value="[^"]*"' | grep -o '[0-9-]*')
    [ -n "$val" ] && echo "$val" || echo "$default"
}
read_pref_str() {
    local key="$1" default="$2"
    [ -f "$PREFS" ] || { echo "$default"; return; }
    val=$(grep "name=\"$key\"" "$PREFS" | grep -o 'value="[^"]*"' | sed 's/value="//;s/"//')
    [ -n "$val" ] && echo "$val" || echo "$default"
}
read_pref_bool() {
    local key="$1" default="$2"
    [ -f "$PREFS" ] || { echo "$default"; return; }
    val=$(grep "name=\"$key\"" "$PREFS" | grep -o 'value="[^"]*"' | grep -o 'true\|false')
    [ -n "$val" ] && echo "$val" || echo "$default"
}

# ── Thermal kısıtlamasını kaldır ────────────────────────────────────────────
unlock_thermal() {
    # sports_mode: 666666666 = "no limit" anlamı MTK'da
    THERMAL_SPORTS="/sys/kernel/thermal/sports_mode"
    if [ -f "$THERMAL_SPORTS" ]; then
        chmod 666 "$THERMAL_SPORTS" 2>/dev/null
        echo 0 > "$THERMAL_SPORTS" 2>/dev/null
    fi

    # mi_thermald'ı durdur (yeniden başlarsa tekrar durdurulacak)
    stop mi_thermald 2>/dev/null

    # CPU thermal zone'larını devre dışı bırak
    for tz_dir in /sys/class/thermal/thermal_zone*/; do
        tz_type=$(cat "${tz_dir}type" 2>/dev/null)
        case "$tz_type" in
            cpu-*|mtk-cpu*)
                echo disabled > "${tz_dir}mode" 2>/dev/null ;;
        esac
    done

    # GPU cooling device cur_state'i sıfırla (throttle kaldır)
    for i in $(seq 0 10); do
        t=$(cat /sys/class/thermal/cooling_device${i}/type 2>/dev/null)
        case "$t" in
            *mali*|*gpu*|*GPU*)
                echo 0 > /sys/class/thermal/cooling_device${i}/cur_state 2>/dev/null ;;
        esac
    done
}

# ── Frekans uygula ───────────────────────────────────────────────────────────
apply_profile() {
    local lmin=$1 lmax=$2 bmin=$3 bmax=$4 pmin=$5 pmax=$6 gmin=$7 gmax=$8

    # CPU
    echo "$lmax" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    echo "$lmin" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq 2>/dev/null
    echo "$bmax" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    echo "$bmin" > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq 2>/dev/null
    echo "$pmax" > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null
    echo "$pmin" > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq 2>/dev/null

    # GPU
    [ -d "$GPU_PATH" ] && {
        echo "$gmax" > "$GPU_PATH/max_freq" 2>/dev/null
        echo "$gmin" > "$GPU_PATH/min_freq" 2>/dev/null
    }

    log "Profil uygulandı: L=$lmin-$lmax B=$bmin-$bmax P=$pmin-$pmax GPU=$gmin-$gmax"
}

# ── Senaryo tespiti ──────────────────────────────────────────────────────────
detect_scenario() {
    local bat_level bat_status screen_state

    bat_level=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 50)
    bat_status=$(cat /sys/class/power_supply/battery/status 2>/dev/null || echo "Discharging")
    screen_state=$(dumpsys display 2>/dev/null | grep "mScreenState" | head -1 | grep -o 'ON\|OFF' || echo "ON")

    # Oyun modu: GameDetectorService flag dosyası bırakır
    [ -f "$GAME_FLAG" ] && { echo "GAMING"; return; }

    # Şarjda veya pil yüksekse: PERFORMANCE
    [ "$bat_status" = "Charging" ] && { echo "PERFORMANCE"; return; }
    [ "$bat_level" -ge 80 ] && { echo "PERFORMANCE"; return; }

    # Pil düşükse: POWERSAVE
    [ "$bat_level" -lt 20 ] && { echo "POWERSAVE"; return; }

    # Ekran kapalı + pil orta: POWERSAVE
    [ "$screen_state" = "OFF" ] && [ "$bat_level" -lt 50 ] && { echo "POWERSAVE"; return; }

    echo "BALANCED"
}

# ── Ana döngü ────────────────────────────────────────────────────────────────
main() {
    log "=== KernelKit FreqUnlock v0.1 başladı ==="

    # thermal_interface modülü yüklenene kadar bekle (max 60s)
    i=0
    while [ $i -lt 60 ]; do
        lsmod 2>/dev/null | grep -q thermal_interface && break
        sleep 1
        i=$((i+1))
    done
    log "thermal_interface yüklendi ($i saniye beklendi)"

    # Modül yüklendi — hemen unlock et ve frekans yaz
    unlock_thermal
    log "Thermal kısıtlama kaldırıldı"

    local last_scenario="" last_mode="" last_prefs_mtime=""

    while true; do
        # Uygulama modu: auto veya manual
        mode=$(read_pref_str "freq_mode" "auto")

        if [ "$mode" = "manual" ]; then
            # Manual: uygulama değerlerini doğrudan uygula
            prefs_mtime=$(stat -c %Y "$PREFS" 2>/dev/null || echo "0")
            if [ "$prefs_mtime" != "$last_prefs_mtime" ] || [ "$mode" != "$last_mode" ]; then
                lmin=$(read_pref_int "little_min" 480000)
                lmax=$(read_pref_int "little_max" 2200000)
                bmin=$(read_pref_int "big_min"    480000)
                bmax=$(read_pref_int "big_max"    3200000)
                pmin=$(read_pref_int "prime_min"  480000)
                pmax=$(read_pref_int "prime_max"  3350000)
                gmin=$(read_pref_int "gpu_min"    265000000)
                gmax=$(read_pref_int "gpu_max"    1400000000)
                apply_profile "$lmin" "$lmax" "$bmin" "$bmax" "$pmin" "$pmax" "$gmin" "$gmax"
                last_prefs_mtime="$prefs_mtime"
                last_mode="$mode"
            fi
        else
            # Auto: senaryoya göre profil seç
            scenario=$(detect_scenario)
            if [ "$scenario" != "$last_scenario" ] || [ "$mode" != "$last_mode" ]; then
                log "Senaryo: $scenario"
                case "$scenario" in
                    POWERSAVE)   apply_profile $POWERSAVE_PROFILE ;;
                    PERFORMANCE) apply_profile $PERFORMANCE_PROFILE ;;
                    GAMING)      apply_profile $GAMING_PROFILE ;;
                    *)           apply_profile $BALANCED_PROFILE ;;
                esac
                last_scenario="$scenario"
                last_mode="$mode"
            fi
        fi

        # Thermal ceiling tekrar devreye girdiyse kaldır
        unlock_thermal

        # TTL fix
        ttl_fix=$(read_pref_bool "ttl_fix" "false")
        [ "$ttl_fix" = "true" ] && {
            ttl_val=$(read_pref_int "ttl_value" 64)
            echo "$ttl_val" > /proc/sys/net/ipv4/ip_default_ttl 2>/dev/null
            echo "$ttl_val" > /proc/sys/net/ipv6/conf/all/hop_limit 2>/dev/null
        }

        sleep 3
    done
}

main &
